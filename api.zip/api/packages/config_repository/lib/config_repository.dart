/// Repository with access to dynamic project configurations
library config_repository;

export 'src/config_repository.dart';
