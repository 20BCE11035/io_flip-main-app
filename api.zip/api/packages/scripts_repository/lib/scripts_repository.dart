/// Access to the game scripts data source
library scripts_repository;

export 'src/scripts_repository.dart';
