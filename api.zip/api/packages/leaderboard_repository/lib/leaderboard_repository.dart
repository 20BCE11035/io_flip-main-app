/// Access to Leaderboard datasource.
library leaderboard_repository;

export 'src/leaderboard_repository.dart';
