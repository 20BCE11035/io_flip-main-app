/// Access to Match datasource
library match_repository;

export 'src/match_repository.dart';
