/// Repository providing access language model services
library language_model_repository;

export 'src/language_model_repository.dart';
