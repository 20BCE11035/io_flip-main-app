/// Holds and proccess the scripts responsible for calculating the result of a
/// game match
library game_script_machine;

export 'src/default_script.dart';
export 'src/game_script_machine.dart';
