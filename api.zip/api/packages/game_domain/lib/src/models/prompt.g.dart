// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prompt.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Prompt _$PromptFromJson(Map<String, dynamic> json) => Prompt(
      characterClass: json['characterClass'] as String?,
      power: json['power'] as String?,
    );

Map<String, dynamic> _$PromptToJson(Prompt instance) => <String, dynamic>{
      'characterClass': instance.characterClass,
      'power': instance.power,
    };
