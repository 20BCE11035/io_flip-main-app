/// Key String representing empty attribute
const emptyKey = 'EMPTY';

/// Key String representing a reserved room for a CPU match
const reservedKey = 'RESERVED_EMPTY';
