/// Access to Prompt datasource.
library prompt_repository;

export 'src/prompt_repository.dart';
