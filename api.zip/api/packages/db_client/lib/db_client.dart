/// Client used to access the game database
library db_client;

export 'src/db_client.dart';
