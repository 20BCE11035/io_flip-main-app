/// Repository providing access image model services
library image_model_repository;

export 'src/image_model_repository.dart';
