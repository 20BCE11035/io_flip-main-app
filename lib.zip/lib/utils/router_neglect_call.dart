import 'package:flutter/widgets.dart';

typedef RouterNeglectCall = void Function(BuildContext, VoidCallback);
